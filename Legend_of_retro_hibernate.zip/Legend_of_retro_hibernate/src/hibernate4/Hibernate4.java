/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate4;

import Classes.Fabricant;
import Util.HibernateUtil;
import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.List;

/**
 *
 * @author iulidora
 */
public class Hibernate4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /*   Fabricant  f1=new Fabricant(); 
       Fabricant  f2=new Fabricant(); 
       Fabricant  f3=new Fabricant(); 
       
       f1.setNomFabricant("Microids");
       f2.setNomFabricant("MavenHut");
       f3.setNomFabricant("Gameloft");
       
       Session s=HibernateUtil.getSessionFactory().getCurrentSession();
       s.beginTransaction();
       //s.save(f1);
       s.save(f2);
       s.save(f3);
       
       s.getTransaction().commit();
      */ 
       //<-----------pour chargement vers la BDD MySQL
       
       
      // Fabricant  f4=new Fabricant(); 
      /* 
       Session s=HibernateUtil.getSessionFactory().getCurrentSession();
       s.beginTransaction();
       
       Session session = HibernateUtil.getSessionFactory().openSession();
       String SQL_QUERY = "from  FABRICANT";

        Query query = session.createQuery(SQL_QUERY);
        session.getTransaction().commit();
        
        for (Iterator it = query.iterate(); it.hasNext();) {
            Object[] row = (Object[]) it.next();
            System.out.println("ID: " + row[0]);
            
     */       
            
            
            try{
        SessionFactory factory=new Configuration().configure().buildSessionFactory();
        Session session=factory.openSession();
        String sql_query= "from  Fabricant";
        Query query=session.createQuery(sql_query);
        System.out.println(query);
        System.out.println("----------------");
        for(Iterator it=query.iterate();it.hasNext();)
        {
           
          Fabricant std = ( Fabricant) it.next();
          System.out.println("serviceTypeID: " + std.getNomFabricant());
        
        // System.out.println("ModeValue: " + validateconfig.getModeValue());
       }
         System.out.println("----------------");
        session.close();
        }catch(Exception e){e.printStackTrace();}

        }
       
  /*     
       
       List<(Classes)Fabricant> list= new (List<(Classes)Fabricant>)s.createQuery("from FABRICANT").list();
       
       for(Fabricant f list){
         System.out.println(f.getNomFabricant());
        }
       
        s.getTransaction().commit();
        
        */
        
    
    
}
